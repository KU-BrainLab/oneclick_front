class Assets {
  static const _ImageAssetConst img = _ImageAssetConst();
}

class _ImageAssetConst {
  const _ImageAssetConst();

  final String icon_logo = 'assets/logo.svg';
}
